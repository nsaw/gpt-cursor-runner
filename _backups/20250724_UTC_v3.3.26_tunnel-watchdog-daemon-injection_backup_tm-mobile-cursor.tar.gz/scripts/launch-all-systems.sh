#!/bin/bash
export EXPO_URL=https://expo-thoughtmarks.THOUGHTMARKS.app
export MONITOR_URL=https://dev-thoughtmarks.THOUGHTMARKS.app
export WEBHOOK_URL=https://webhook-thoughtmarks.THOUGHTMARKS.app
export GHOST_URL=https://ghost-thoughtmarks.THOUGHTMARKS.app
export RUNNER_URL=https://runner-thoughtmarks.THOUGHTMARKS.app
export HEALTHCHECK_URL=https://health-thoughtmarks.THOUGHTMARKS.app

echo "🚀 Launching ALL Systems for MAIN and CYOPS..."
echo "================================================"

# Create logs directory if it doesn't exist
mkdir -p logs/

# Function to launch a service with proper logging
launch_service() {
    local service_name=$1
    local command=$2
    local log_file=$3
    
    echo "📦 Starting $service_name..."
    nohup bash -c "$command" > "logs/$log_file" 2>&1 &
    disown
    echo "   ✅ $service_name launched (PID: $!)"
}

# Function to launch tunnel services
launch_tunnel() {
    local tunnel_name=$1
    local command=$2
    local log_file=$3
    
    echo "🌐 Starting $tunnel_name..."
    nohup bash -c "$command" > "logs/$log_file" 2>&1 &
    disown
    echo "   ✅ $tunnel_name launched (PID: $!)"
}

# Function to launch watchdog daemons
launch_watchdog() {
    local watchdog_name=$1
    local command=$2
    local log_file=$3
    
    echo "🛡️  Starting $watchdog_name..."
    nohup bash -c "$command" > "logs/$log_file" 2>&1 &
    disown
    echo "   ✅ $watchdog_name launched (PID: $!)"
}

# MAIN System Services
echo ""
echo "🔵 MAIN System Services:"
echo "-----------------------"

# Launch MAIN patch-executor
launch_service "MAIN patch-executor" \
    "cd /Users/sawyer/gitSync/tm-mobile-cursor && node scripts/patch-executor.js" \
    "main-patch-executor.log"

# Launch MAIN ghost-bridge
launch_service "MAIN ghost-bridge" \
    "cd /Users/sawyer/gitSync/tm-mobile-cursor && node scripts/ghost-bridge.js" \
    "main-ghost-bridge.log"

# Launch MAIN summary-monitor
launch_service "MAIN summary-monitor" \
    "cd /Users/sawyer/gitSync/tm-mobile-cursor && node scripts/summary-monitor.js" \
    "main-summary-monitor.log"

# Launch MAIN realtime-monitor
launch_service "MAIN realtime-monitor" \
    "cd /Users/sawyer/gitSync/tm-mobile-cursor && node scripts/realtime-monitor.js" \
    "main-realtime-monitor.log"

# CYOPS System Services
echo ""
echo "🟡 CYOPS System Services:"
echo "------------------------"

# Launch CYOPS patch-executor
launch_service "CYOPS patch-executor" \
    "cd /Users/sawyer/gitSync/gpt-cursor-runner && node scripts/patch-executor.js" \
    "cyops-patch-executor.log"

# Launch CYOPS ghost-bridge
launch_service "CYOPS ghost-bridge" \
    "cd /Users/sawyer/gitSync/gpt-cursor-runner && node scripts/ghost-bridge.js" \
    "cyops-ghost-bridge.log"

# Launch CYOPS summary-monitor
launch_service "CYOPS summary-monitor" \
    "cd /Users/sawyer/gitSync/gpt-cursor-runner && node scripts/summary-monitor.js" \
    "cyops-summary-monitor.log"

# Launch CYOPS realtime-monitor
launch_service "CYOPS realtime-monitor" \
    "cd /Users/sawyer/gitSync/gpt-cursor-runner && node scripts/realtime-monitor.js" \
    "cyops-realtime-monitor.log"

# Launch doc-sync
launch_service "CYOPS doc-sync" \
    "cd /Users/sawyer/gitSync/gpt-cursor-runner && node scripts/doc-sync.js" \
    "cyops-doc-sync.log"

# Launch orchestrator
launch_service "CYOPS orchestrator" \
    "cd /Users/sawyer/gitSync/gpt-cursor-runner && node scripts/system/orchestrator.js" \
    "cyops-orchestrator.log"

# Launch daemon-manager
launch_service "CYOPS daemon-manager" \
    "cd /Users/sawyer/gitSync/gpt-cursor-runner && node scripts/daemon-manager.js" \
    "cyops-daemon-manager.log"

# Tunnel Services
echo ""
echo "🌐 Tunnel Services:"
echo "------------------"

# Launch Cloudflare tunnel with config
launch_tunnel "Cloudflare tunnel" \
    "cd /Users/sawyer/gitSync/gpt-cursor-runner && cloudflared --config config/simple-tunnel-config.yml tunnel run" \
    "cloudflare-tunnel.log"

# Launch ngrok tunnel (if available)
if command -v ngrok &> /dev/null; then
    launch_tunnel "ngrok tunnel" \
        "cd /Users/sawyer/gitSync/gpt-cursor-runner && ngrok http 8787" \
        "ngrok-tunnel.log"
else
    echo "   ⚠️  ngrok not found, skipping ngrok tunnel"
fi

# Launch additional ngrok tunnels for other services
if command -v ngrok &> /dev/null; then
    # ngrok for ghost-runner
    launch_tunnel "ngrok ghost-runner" \
        "cd /Users/sawyer/gitSync/gpt-cursor-runner && ngrok http 5051" \
        "ngrok-ghost-runner.log"
    
    # ngrok for webhook endpoint
    launch_tunnel "ngrok webhook" \
        "cd /Users/sawyer/gitSync/gpt-cursor-runner && ngrok http 5555" \
        "ngrok-webhook.log"
fi

# Watchdog Daemons
echo ""
echo "🛡️  Watchdog Daemons:"
echo "-------------------"

# Launch tunnel watchdog
launch_watchdog "tunnel watchdog" \
    "cd /Users/sawyer/gitSync/gpt-cursor-runner && bash runner/tunnel-watchdog.sh" \
    "tunnel-watchdog.log"

# Launch system health watchdog
launch_watchdog "system health watchdog" \
    "cd /Users/sawyer/gitSync/gpt-cursor-runner && node scripts/watchdogs/system-health-watchdog.js" \
    "system-health-watchdog.log"

# Launch service watchdog
launch_watchdog "service watchdog" \
    "cd /Users/sawyer/gitSync/gpt-cursor-runner && node scripts/watchdogs/service-watchdog.js" \
    "service-watchdog.log"

# Launch patch watchdog
launch_watchdog "patch watchdog" \
    "cd /Users/sawyer/gitSync/gpt-cursor-runner && node scripts/watchdogs/patch-watchdog.js" \
    "patch-watchdog.log"

# Deployment Services
echo ""
echo "🚀 Deployment Services:"
echo "---------------------"

# Launch Fly.io deployment (if available)
if command -v flyctl &> /dev/null; then
    launch_service "Fly.io deployment" \
        "cd /Users/sawyer/gitSync/gpt-cursor-runner && flyctl deploy --remote-only" \
        "fly-deployment.log"
else
    echo "   ⚠️  flyctl not found, skipping Fly.io deployment"
fi

# Launch Fly.io app monitoring
if command -v flyctl &> /dev/null; then
    launch_service "Fly.io monitoring" \
        "cd /Users/sawyer/gitSync/gpt-cursor-runner && flyctl status" \
        "fly-status.log"
fi

# PM2 Services
echo ""
echo "🟢 PM2 Services:"
echo "---------------"

# Start PM2 ecosystem (includes dual-monitor)
echo "📦 Starting PM2 ecosystem..."
{ pm2 start ecosystem.config.js & } >/dev/null 2>&1 & disown
echo "   ✅ PM2 ecosystem launched"

# Wait a moment for services to start
echo ""
echo "⏳ Waiting 15 seconds for services to initialize..."
sleep 15

# Health checks
echo ""
echo "🔍 Health Checks:"
echo "----------------"

# Check MAIN services
echo "🔵 MAIN System Health:"
{ curl -s http://localhost:3000/health >/dev/null && echo "   ✅ MAIN backend (port 3000)" || echo "   ❌ MAIN backend (port 3000)" & } >/dev/null 2>&1 & disown
{ curl -s http://localhost:8081/status >/dev/null && echo "   ✅ MAIN expo-dev-server (port 8081)" || echo "   ❌ MAIN expo-dev-server (port 8081)" & } >/dev/null 2>&1 & disown

# Check CYOPS services
echo "🟡 CYOPS System Health:"
{ curl -s http://localhost:5051/health >/dev/null && echo "   ✅ CYOPS ghost-runner (port 5051)" || echo "   ❌ CYOPS ghost-runner (port 5051)" & } >/dev/null 2>&1 & disown
{ curl -s http://localhost:8787/monitor >/dev/null && echo "   ✅ CYOPS dual-monitor (port 8787)" || echo "   ❌ CYOPS dual-monitor (port 8787)" & } >/dev/null 2>&1 & disown
{ curl -s http://localhost:5555/webhook >/dev/null && echo "   ✅ CYOPS webhook (port 5555)" || echo "   ❌ CYOPS webhook (port 5555)" & } >/dev/null 2>&1 & disown

# Check tunnel services
echo "🌐 Tunnel Health:"
{ curl -s https://gpt-cursor-runner.thoughtmarks.app/monitor >/dev/null && echo "   ✅ Cloudflare tunnel" || echo "   ❌ Cloudflare tunnel" & } >/dev/null 2>&1 & disown

# Check PM2 status
echo ""
echo "📊 PM2 Status:"
{ pm2 status & } >/dev/null 2>&1 & disown

# Check tunnel status
echo ""
echo "🌐 Tunnel Status:"
{ cloudflared tunnel info gpt-cursor-runner & } >/dev/null 2>&1 & disown

echo ""
echo "✅ All systems launched!"
echo "📁 Logs available in: logs/"
echo "🌐 Local Monitor: http://localhost:8787/monitor"
echo "🌐 Public Monitor: https://gpt-cursor-runner.thoughtmarks.app/monitor"
echo "🌐 Ghost Status: http://localhost:5051/health"
echo ""
echo "💡 To stop all services: ./scripts/stop-all-systems.sh"
echo "💡 To view logs: tail -f logs/[service-name].log" 