#!/usr/bin/env node

/**
 * Real Dual Monitor
 * Shows patch execution status for both MAIN and CYOPS systems
 * Provides live monitoring of patch execution and system status for dual projects
 */

const fs = require('fs');
const path = require('path');
const { exec } = require('child_process');

// Import filename concatenator utility
const { concatenateFilename } = require('../utils/filename-concatenator');

// Replace execSync calls with non-blocking exec
function checkProcessStatus(processName) {
  return new Promise((resolve) => {
    exec(`ps aux | grep "${processName}" | grep -v grep`, { encoding: 'utf8' }, (error, stdout, _stderr) => {
      if (error) {
        resolve({ running: false, error: error.message });
      } else {
        resolve({ running: stdout.trim().length > 0, output: stdout.trim() });
      }
    });
  });
}

function checkCurlHealth(url) {
  return new Promise((resolve) => {
    exec(`curl -s -m 5 "${url}"`, { encoding: 'utf8' }, (error, stdout, _stderr) => {
      if (error) {
        resolve({ healthy: false, error: error.message });
      } else {
        resolve({ healthy: true, response: stdout.trim() });
      }
    });
  });
}

class RealDualMonitor {
  constructor() {
    this.monitoring = false;
    this.statusInterval = null;
    this.lastStatus = {};
        
    // System configurations
    this.systems = {
      MAIN: {
        label: 'MAIN',
        root: '/Users/sawyer/gitSync/tm-mobile-cursor',
        patchesPath: '/Users/sawyer/gitSync/.cursor-cache/MAIN/patches',
        summariesPath: '/Users/sawyer/gitSync/.cursor-cache/MAIN/summaries',
        logsPath: '/Users/sawyer/gitSync/tm-mobile-cursor/logs',
        ghostUrl: 'https://runner.thoughtmarks.app/health'
      },
      CYOPS: {
        label: 'CYOPS',
        root: '/Users/sawyer/gitSync/gpt-cursor-runner',
        patchesPath: '/Users/sawyer/gitSync/.cursor-cache/CYOPS/patches',
        summariesPath: '/Users/sawyer/gitSync/.cursor-cache/CYOPS/summaries',
        logsPath: '/Users/sawyer/gitSync/gpt-cursor-runner/logs',
        ghostUrl: 'https://gpt-cursor-runner.fly.dev/health'
      }
    };
        
    // Status categories for each system
    this.statusCategories = {
      MAIN: {
        patches: { pending: 0, executing: 0, completed: 0, failed: 0 },
        systems: { running: [], stopped: [], errors: [] },
        ghost: { status: 'unknown', lastCheck: null },
        execution: { current: null, queue: [], history: [] }
      },
      CYOPS: {
        patches: { pending: 0, executing: 0, completed: 0, failed: 0 },
        systems: { running: [], stopped: [], errors: [] },
        ghost: { status: 'unknown', lastCheck: null },
        execution: { current: null, queue: [], history: [] }
      }
    };
  }

  // Start dual system monitoring
  start() {
    console.log('🔍 Starting Real Dual Monitor...');
    this.monitoring = true;
        
    // Initial status check
    this.updateStatus();
        
    // Set up periodic status updates
    this.statusInterval = setInterval(() => {
      this.updateStatus();
    }, 5000); // Update every 5 seconds
        
    // Set up file watchers for both systems
    this.watchSystems();
        
    console.log('✅ Real Dual Monitor started');
    console.log('📊 Status updates every 5 seconds');
    console.log('👁️  Watching for patch and summary changes in both systems');
  }

  // Stop monitoring
  stop() {
    console.log('🛑 Stopping Real Dual Monitor...');
    this.monitoring = false;
        
    if (this.statusInterval) {
      clearInterval(this.statusInterval);
      this.statusInterval = null;
    }
        
    console.log('✅ Real Dual Monitor stopped');
  }

  // Update current status for both systems
  async updateStatus() {
    Object.keys(this.systems).forEach(systemKey => {
      this.checkPatchStatus(systemKey);
      this.checkSystemStatus(systemKey);
      this.checkGhostStatus(systemKey);
    });
    this.displayStatus();
  }

  // Extract patch ID from filename
  extractPatchId(filename) {
    if (filename.startsWith('patch-')) {
      return filename.replace(/^patch-/, '').replace(/\.json$/, '');
    }
    if (filename.startsWith('summary-')) {
      return filename.replace(/^summary-/, '').replace(/\.md$/, '');
    }
    return filename.replace(/\.(json|md)$/, '');
  }

  // Check patch status for a specific system
  async checkPatchStatus(systemKey) {
    try {
      const system = this.systems[systemKey];
      const patchesPath = system.patchesPath;
      const summariesPath = system.summariesPath;
            

            
      // Get patch files
      const patchDirContents = fs.readdirSync(patchesPath);
      const patchFiles = patchDirContents
        .filter(f => f.endsWith('.json'))
        .filter(f => !f.startsWith('.')) // Exclude hidden files
        .filter(f => fs.existsSync(path.join(patchesPath, f))); // Ensure exists

      // Get summary files
      const summaryDirContents = fs.readdirSync(summariesPath);
      const summaryFiles = summaryDirContents
        .filter(f => f.endsWith('.md'))
        .filter(f => !f.startsWith('.')) // Exclude hidden files
        .filter(f => fs.existsSync(path.join(summariesPath, f))); // Ensure exists

      // Extract completed patch IDs from summary files
      const completedIds = summaryFiles.map(f => this.extractPatchId(f));

      // Filter pending patches - only include patches that don't have corresponding summaries
      const pendingPatches = patchFiles.filter(patchFile => {
        const patchId = this.extractPatchId(patchFile);
        return !completedIds.includes(patchId);
      });

      const status = {
        pending: pendingPatches.length,
        executing: 0,
        completed: completedIds.length,
        failed: 0
      };
            
      this.statusCategories[systemKey].patches = status;
    } catch (error) {
      console.error(`❌ Error checking patch status for ${systemKey}:`, error.message);
      console.error(`   Patches path: ${this.systems[systemKey].patchesPath}`);
      console.error(`   Summaries path: ${this.systems[systemKey].summariesPath}`);
      this.statusCategories[systemKey].patches = { pending: 0, executing: 0, completed: 0, failed: 0 };
    }
  }

  // Check system status for a specific system
  async checkSystemStatus(systemKey) {
    const systems = {
      running: [],
      stopped: [],
      errors: []
    };
        
    const systemChecks = [
      { name: 'patch-executor', process: 'patch-executor' },
      { name: 'ghost-bridge', process: 'ghost-bridge' },
      { name: 'summary-monitor', process: 'summary-monitor' },
      { name: 'realtime-monitor', process: 'realtime-monitor' }
    ];
        
    // Add system-specific checks
    if (systemKey === 'MAIN') {
      systemChecks.push({ name: 'expo-dev-server', process: 'expo' });
    } else if (systemKey === 'CYOPS') {
      systemChecks.push({ name: 'tunnel', process: 'cloudflared' });
      systemChecks.push({ name: 'fly.io', process: 'fly' });
      systemChecks.push({ name: 'doc-sync', process: 'doc-sync' });
      systemChecks.push({ name: 'orchestrator', process: 'orchestrator' });
      systemChecks.push({ name: 'daemon-manager', process: 'daemon-manager' });
    }
        
    for (const check of systemChecks) {
      try {
        const result = await checkProcessStatus(check.process);
        if (result.running) {
          systems.running.push(check.name);
        } else {
          systems.stopped.push(check.name);
        }
      } catch (error) {
        systems.stopped.push(check.name);
      }
    }
        
    this.statusCategories[systemKey].systems = systems;
  }

  // Check ghost runner status for a specific system
  async checkGhostStatus(systemKey) {
    try {
      const system = this.systems[systemKey];
      const curlCheck = await checkCurlHealth(system.ghostUrl);
      if (curlCheck.healthy) {
        this.statusCategories[systemKey].ghost = {
          status: 'running',
          lastCheck: new Date().toISOString()
        };
      } else {
        this.statusCategories[systemKey].ghost = {
          status: 'unreachable',
          lastCheck: new Date().toISOString()
        };
      }
    } catch (error) {
      this.statusCategories[systemKey].ghost = {
        status: 'unreachable',
        lastCheck: new Date().toISOString()
      };
    }
  }

  // Display current status for both systems
  displayStatus() {
    console.clear();
    console.log('🔍 REAL DUAL MONITOR - PATCH EXECUTION STATUS');
    console.log('=' .repeat(60));
    console.log(`📅 ${new Date().toLocaleString()}`);
    console.log('');
        
    // Patch Status for both systems
    console.log('📦 PATCH STATUS:');
    Object.keys(this.systems).forEach(systemKey => {
      const patches = this.statusCategories[systemKey].patches;
      console.log(`   [ ${systemKey} ] Pending: ${patches.pending} | Executing: ${patches.executing} | Completed: ${patches.completed} | Failed: ${patches.failed}`);
    });
        
    // Check if any system has pending patches
    const hasPending = Object.keys(this.systems).some(systemKey => 
      this.statusCategories[systemKey].patches.pending > 0
    );
    if (hasPending) {
      console.log('   ⚠️  Pending patches detected!');
    }
        
    console.log('');
        
    // Execution Queue for both systems
    console.log('🔄 EXECUTION QUEUE:');
    Object.keys(this.systems).forEach(systemKey => {
      console.log(`   [ ${systemKey} ]`);
      this.showExecutionQueue(systemKey);
    });
        
    console.log('');
        
    // System Status for both systems
    console.log('🖥️  SYSTEM STATUS:');
    Object.keys(this.systems).forEach(systemKey => {
      console.log(`   [ ${systemKey} ]`);
      const systems = this.statusCategories[systemKey].systems;
      if (systems.running.length > 0) {
        console.log(`   ✅ Running: ${systems.running.join(', ')}`);
      }
      if (systems.stopped.length > 0) {
        console.log(`   ❌ Stopped: ${systems.stopped.join(', ')}`);
      }
      if (systems.errors.length > 0) {
        console.log(`   🚨 Errors: ${systems.errors.join(', ')}`);
      }
      console.log('');
    });
        
    // Ghost Status for both systems
    console.log('👻 GHOST RUNNER STATUS:');
    Object.keys(this.systems).forEach(systemKey => {
      const ghost = this.statusCategories[systemKey].ghost;
      const statusIcon = ghost.status === 'running' ? '✅' : '❌';
      console.log(`   [ ${systemKey} ] ${statusIcon} ${ghost.status.toUpperCase()}`);
    });
    console.log(`   Last Check: ${new Date().toISOString()}`);
        
    console.log('');
        
    // Recent Activity for both systems
    console.log('📋 RECENT ACTIVITY:');
    Object.keys(this.systems).forEach(systemKey => {
      console.log(`   [ ${systemKey} ]`);
      this.showRecentActivity(systemKey);
    });
        
    console.log('');
    console.log('=' .repeat(60));
    console.log('💡 Commands: start | stop | execute | status');
  }

  // Show execution queue for a specific system
  showExecutionQueue(systemKey) {
    try {
      const system = this.systems[systemKey];
      const patchFiles = fs.readdirSync(system.patchesPath)
        .filter(f => f.endsWith('.json'))
        .filter(f => !f.startsWith('.'))
        .filter(f => fs.existsSync(path.join(system.patchesPath, f)));

      const summaryFiles = fs.readdirSync(system.summariesPath)
        .filter(f => f.endsWith('.md'))
        .filter(f => !f.startsWith('.'))
        .filter(f => fs.existsSync(path.join(system.summariesPath, f)));

      const completedIds = summaryFiles.map(f => this.extractPatchId(f));
      const pendingPatches = patchFiles.filter(patchFile => {
        const patchId = this.extractPatchId(patchFile);
        return !completedIds.includes(patchId);
      });

      if (pendingPatches.length > 0) {
        pendingPatches.forEach(patch => {
          console.log(`   ⏳ ${patch} (queued)`);
        });
      } else {
        console.log('   ✅ No pending patches in queue');
      }
    } catch (error) {
      console.log('   Error reading execution queue');
    }
  }

  // Show recent activity for a specific system
  showRecentActivity(systemKey) {
    try {
      const system = this.systems[systemKey];
      const summaryFiles = fs.readdirSync(system.summariesPath)
        .filter(f => f.endsWith('.md'))
        .sort((a, b) => {
          const aStat = fs.statSync(path.join(system.summariesPath, a));
          const bStat = fs.statSync(path.join(system.summariesPath, b));
          return bStat.mtime - aStat.mtime;
        })
        .slice(0, 3); // Show last 3 for each system
            
      if (summaryFiles.length > 0) {
        summaryFiles.forEach(file => {
          const stat = fs.statSync(path.join(system.summariesPath, file));
          const concatenatedFile = concatenateFilename(file);
          console.log(`   📄 ${concatenatedFile} (${stat.mtime.toLocaleTimeString()})`);
        });
      } else {
        console.log('   No recent activity');
      }
    } catch (error) {
      console.log('   Error reading recent activity');
    }
  }

  // Watch both systems for changes
  watchSystems() {
    Object.keys(this.systems).forEach(systemKey => {
      const system = this.systems[systemKey];
            
      // Watch patches directory
      try {
        fs.watch(system.patchesPath, (eventType, filename) => {
          if (filename && filename.endsWith('.json')) {
            console.log(`📦 ${systemKey} patch file change detected: ${filename}`);
            this.updateStatus();
          }
        });
      } catch (error) {
        console.log(`⚠️  Could not watch ${systemKey} patches directory`);
      }
            
      // Watch summaries directory
      try {
        fs.watch(system.summariesPath, (eventType, filename) => {
          if (filename && filename.endsWith('.md')) {
            console.log(`📫 ${systemKey} summary file change detected: ${filename}`);
            this.updateStatus();
          }
        });
      } catch (error) {
        console.log(`⚠️  Could not watch ${systemKey} summaries directory`);
      }
    });
        
    console.log('👁️  Watching both systems for changes...');
  }

  // Execute pending patches for both systems
  executePatches() {
    console.log('🚀 Executing pending patches for both systems...');
        
    Object.keys(this.systems).forEach(systemKey => {
      const system = this.systems[systemKey];
      console.log(`   Executing patches for ${systemKey}...`);
            
      // Execute patches for each system
      exec(`cd "${system.root}" && node scripts/patch-executor.js execute`, (error, stdout, _stderr) => {
        if (error) {
          console.error(`❌ ${systemKey} patch execution failed:`, error.message);
        } else {
          console.log(`✅ ${systemKey} patch execution completed`);
          console.log(stdout);
        }
      });
    });
  }

  // Get detailed status for both systems
  getDetailedStatus() {
    return {
      timestamp: new Date().toISOString(),
      systems: this.statusCategories
    };
  }

  // Get status formatted for agent chat
  getStatusForAgent() {
    // Update status before generating agent output
    this.updateStatus();
        
    let statusText = '🔍 **REAL DUAL MONITOR - PATCH EXECUTION STATUS**\n\n';
        
    // Patch Status for both systems
    statusText += '📦 **Patch Status:**\n';
    Object.keys(this.systems).forEach(systemKey => {
      const patches = this.statusCategories[systemKey].patches;
      statusText += `   [ ${systemKey} ] Pending: ${patches.pending} | Executing: ${patches.executing} | Completed: ${patches.completed} | Failed: ${patches.failed}\n`;
    });
    statusText += '\n';
        
    // Check if any system has pending patches
    const hasPending = Object.keys(this.systems).some(systemKey => 
      this.statusCategories[systemKey].patches.pending > 0
    );
    if (hasPending) {
      statusText += '⚠️ **PENDING PATCHES DETECTED!**\n\n';
    }
        
    // System Status for both systems
    statusText += '🖥️ **System Status:**\n';
    Object.keys(this.systems).forEach(systemKey => {
      statusText += `   [ ${systemKey} ]\n`;
      const systems = this.statusCategories[systemKey].systems;
      if (systems.running.length > 0) {
        statusText += `   ✅ Running: ${systems.running.join(', ')}\n`;
      }
      if (systems.stopped.length > 0) {
        statusText += `   ❌ Stopped: ${systems.stopped.join(', ')}\n`;
      }
      if (systems.errors.length > 0) {
        statusText += `   🚨 Errors: ${systems.errors.join(', ')}\n`;
      }
    });
    statusText += '\n';
        
    // Ghost Status for both systems
    statusText += '👻 **Ghost Runner Status:**\n';
    Object.keys(this.systems).forEach(systemKey => {
      const ghost = this.statusCategories[systemKey].ghost;
      const statusIcon = ghost.status === 'running' ? '✅' : '❌';
      statusText += `   [ ${systemKey} ] ${statusIcon} ${ghost.status.toUpperCase()}\n`;
    });
    statusText += '\n';
        
    // Recent Activity for both systems
    statusText += '📋 **Recent Activity:**\n';
    Object.keys(this.systems).forEach(systemKey => {
      statusText += `   [ ${systemKey} ]\n`;
      try {
        const system = this.systems[systemKey];
        const summaryFiles = fs.readdirSync(system.summariesPath)
          .filter(f => f.endsWith('.md'))
          .sort((a, b) => {
            const aStat = fs.statSync(path.join(system.summariesPath, a));
            const bStat = fs.statSync(path.join(system.summariesPath, b));
            return bStat.mtime - aStat.mtime;
          })
          .slice(0, 3);
                
        if (summaryFiles.length > 0) {
          summaryFiles.forEach(file => {
            const stat = fs.statSync(path.join(system.summariesPath, file));
            const concatenatedFile = concatenateFilename(file);
            statusText += `   📄 ${concatenatedFile} (${stat.mtime.toLocaleTimeString()})\n`;
          });
        } else {
          statusText += '   No recent activity\n';
        }
      } catch (error) {
        statusText += '   Error reading recent activity\n';
      }
    });
        
    statusText += `🕐 **Last Update:** ${new Date().toLocaleTimeString()}`;
        
    return statusText;
  }
}

// CLI interface
const monitor = new RealDualMonitor();

const command = process.argv[2];

switch (command) {
case 'start':
  monitor.start();
  break;
case 'stop':
  monitor.stop();
  break;
case 'execute':
  monitor.executePatches();
  break;
case 'status':
  monitor.updateStatus();
  break;
case 'agent':
  console.log(monitor.getStatusForAgent());
  break;
default:
  console.log('🔍 Real Dual Monitor');
  console.log('');
  console.log('Usage: node dualMonitor.js [start|stop|execute|status|agent]');
  console.log('');
  console.log('Commands:');
  console.log('  start   - Start monitoring both MAIN and CYOPS systems');
  console.log('  stop    - Stop monitoring');
  console.log('  execute - Execute pending patches for both systems');
  console.log('  status  - Show current status once');
  console.log('  agent   - Show formatted status for agent chat');
  console.log('');
  console.log('This monitor provides real-time patch execution status');
  console.log('for both MAIN and CYOPS systems in a unified view.');
}