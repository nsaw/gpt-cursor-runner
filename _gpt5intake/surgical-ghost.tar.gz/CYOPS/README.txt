Core Ops Scripts + Dependencies (per _COMPREHENSIVE-DEPENDENCY.md)
Built: 2025-08-08T22:41:32Z
Root: /Users/sawyer/gitSync/gpt-cursor-runner
